# CloudRun Analyze
This is a Python Flask app deployed to GCP Cloud Run using Terraform and GitHub Actions.
