from app import app
import json

def test_analyze_success():
    client = app.test_client()
    resp = client.post('/analyze', json={'text': 'I love cloud engineering!'})
    assert resp.status_code == 200
    data = resp.get_json()
    assert 'word_count' in data
    assert 'character_count' in data

def test_analyze_bad_request():
    client = app.test_client()
    resp = client.post('/analyze', data='notjson')
    assert resp.status_code == 400
