from flask import Flask, request, jsonify
import os

app = Flask(__name__)

@app.route('/analyze', methods=['POST'])
def analyze():
    payload = request.get_json(silent=True)
    if not payload or 'text' not in payload:
        return jsonify({'error': 'Request must be JSON with a "text" field.'}), 400

    text = payload['text'] or ''
    word_count = len(text.split())
    character_count = len(text)

    return jsonify({
        'original_text': text,
        'word_count': word_count,
        'character_count': character_count
    })

if __name__ == '__main__':
    port = int(os.environ.get('PORT', 8080))
    app.run(host='0.0.0.0', port=port)
